"use client"

import { Input } from "@/src/components/ui/input"
import { Label } from "@/src/components/ui/label"
import { Card, CardContent } from "@/src/components/ui/card"
import { Dispatch, SetStateAction, useState } from "react"
import { Button } from "../ui/button"
import { SelectUser } from "@/src/db/schema"
import { Controller, useForm } from "react-hook-form"
import { useServerAction } from "@/src/hooks/useServerAction"
import { toast } from "@/src/hooks/use-toast"
import {
  updateUserProfileAction,
  userProfileCompletionAction
} from "@/src/server-actions/profile/profile"
import { socialPlatforms } from "./constants"
import { isValidUrl, normalizeUrl } from "@/src/utils/clientHelper"
import { useSetAtom } from "jotai"
import { userStore } from "@/src/store/user/userStore"
interface StepThreeProps {
  step: number
  setStep: Dispatch<SetStateAction<number>>
  user: SelectUser
  setUser: Dispatch<SetStateAction<SelectUser | undefined>>
  totalSteps?: number
  isMentor?: boolean
}

export function StepThree({
  step,
  setStep,
  user,
  setUser,
  totalSteps = 4,
  isMentor = false
}: StepThreeProps) {
  const [submitDataLoading, , , submitUserProfileData] = useServerAction(
    userProfileCompletionAction
  )
  const [isTransitioning, setIsTransitioning] = useState(false)
  const setUserProfile = useSetAtom(userStore.AuthUser)

  const ReferralId = localStorage.getItem("referral_id")
  const form = useForm({})

  const handlePrevious = () => {
    setStep((prev) => prev - 1)
    window.scrollTo(0, 0)
  }

  async function submitData(data: any) {
    if (isMentor && !data.linkedin?.trim()) {
      form.setError("linkedin", {
        message: "LinkedIn URL is required for mentors"
      })
      return
    }
    if (isMentor && !isValidUrl(data.linkedin)) {
      form.setError("linkedin", { message: "Please enter a valid URL" })
      return
    }

    setIsTransitioning(true)
    try {
      const socialPlatforms = {
        linkedin_url: normalizeUrl(data.linkedin || ""),
        github_url: normalizeUrl(data.github || ""),
        instagram_url: normalizeUrl(data.instagram || ""),
        twitter_url: normalizeUrl(data.twitter || ""),
        personal_website_url: normalizeUrl(data.website || "")
      }
      const hasAnyLink = Object.values(socialPlatforms).some(
        (val) => val && val.trim() !== ""
      )

      const finalData = {
        ...socialPlatforms,
        is_profile_completed: 1
      }

      const res = await submitUserProfileData(
        user.unique_id,
        finalData,
        ReferralId || ""
      )

      if (res?.success) {
        setUserProfile((prev) => (prev ? { ...prev, profile: res.data } : null))
        toast({
          title: hasAnyLink
            ? "Social links added successfully"
            : "Profile data saved successfully",
          duration: 2000
        })

        if (!submitDataLoading) {
          setStep((prev) => prev + 1)
        }
      } else {
        setIsTransitioning(false)
      }
    } catch (error) {
      console.error("Error submitting social links:", error)
      toast({
        title: "Failed to save Data",
        variant: "destructive",
        duration: 2000
      })
      setIsTransitioning(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold">Social Links</h3>
        <p className="text-sm text-muted-foreground">
          {isMentor
            ? "Connect your social profiles (LinkedIn is required for mentors)"
            : "Connect your social profiles (optional)"}
        </p>
      </div>

      <div className="grid gap-4">
        <form onSubmit={form.handleSubmit(submitData)}>
          {socialPlatforms.map((platform) => {
            const IconComponent = platform.icon
            const isRequired = isMentor && platform.key === "linkedin"
            return (
              <Card key={platform.key} className="border-0 shadow-sm">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 border rounded-full`}>
                      <IconComponent className={`h-5 w-5`} />
                    </div>
                    <div className="flex-1 space-y-2">
                      <Label htmlFor={platform.key} className="font-semibold">
                        {platform.label}
                        {isRequired && <span className="text-red-500"> *</span>}
                      </Label>
                      <Controller
                        name={platform.key}
                        defaultValue=""
                        control={form.control}
                        render={({ field }) => (
                          <Input
                            id={platform.key}
                            placeholder={platform.placeholder}
                            type="url"
                            {...field}
                          />
                        )}
                      />
                      {isRequired && form.formState.errors.linkedin && (
                        <p className="text-red-500 text-sm">
                          {String(form.formState.errors.linkedin.message)}
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
          {step < totalSteps && (
            <div className="flex justify-between pt-6 border-t">
              <Button
                variant="outline"
                onClick={handlePrevious}
                disabled={step === 1}
              >
                Previous
              </Button>
              <Button loading={submitDataLoading} disabled={isTransitioning}>
                Continue
              </Button>
            </div>
          )}
        </form>
      </div>
    </div>
  )
}
