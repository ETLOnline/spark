import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle
} from "@/src/components/ui/dialog"
import { projectStore } from "@/src/store/project/projectStore"
import { useAtom, useSetAtom } from "jotai"
import { useSearchParams, useRouter, usePathname } from "next/navigation"
import React, {
  Dispatch,
  SetStateAction,
  useCallback,
  useEffect,
  useState
} from "react"
import { ScrollArea } from "@/src/components/ui/scroll-area"
import TaskFormHeader from "./TaskFormHeader"
import TaskForm from "./TaskForm"
import { SelectTask } from "@/src/db/schema"
import { useServerAction } from "@/src/hooks/useServerAction"
import { GetTaskByIdAction } from "@/src/server-actions/Tasks/Task"
import { toast } from "@/src/hooks/use-toast"
import useTaskHook from "../hooks/useTaskHook"
import { taskStore } from "@/src/store/tasks/taskStore"
import { useConfirmClose } from "@/src/hooks/useConfirmClose"
import { UnsavedChangesDialog } from "@/src/components/common/unsavedChangesDialog"

interface TaskModalProps {
  isTaskModelOpen: boolean
  setIsTaskModelOpen: Dispatch<SetStateAction<boolean>>
  selectedTask?: SelectTask
  sprintId?: string
  onCreateComplete?: (task: SelectTask) => void
  onUpdateComplete?: (task: SelectTask) => void
  isReady?: boolean
  onSubTaskCreate?: (task: SelectTask) => void
  isSprintCompleted?: boolean
  verificationStatus?: {
    status: string
    verification_id: number
    feedback: string | null
  } | null
  onVerificationStatusChange?: (newStatus: string, newFeedback: string) => void
}

export const TaskModal = ({
  isTaskModelOpen,
  setIsTaskModelOpen,
  selectedTask,
  onCreateComplete,
  onUpdateComplete,
  sprintId,
  isReady,
  onSubTaskCreate,
  isSprintCompleted = false,
  verificationStatus,
  onVerificationStatusChange
}: TaskModalProps) => {
  const setSelectedTask = useSetAtom(taskStore.selectedTask)
  const [taskIdFromUrl, setTaskIdFromUrl] = useState<string | null>(null)
  const [statuses] = useAtom(projectStore.projectStatusList)
  const [refetchComments, setRefetchComments] = useState(false)
  const { createTaskLoading, updateTaskLoading, handleSubmit } = useTaskHook({
    selectedTask,
    sprintId,
    onCreateComplete: (task) => {
      onCreateComplete?.(task)
      setIsChanged(false)
    },
    onUpdateComplete: (task) => {
      onUpdateComplete?.(task)
      setIsChanged(false)
      setRefetchComments(true)
    },
    setIsTaskModelOpen,
    setSelectedTask
  })

  const [isChanged, setIsChanged] = useState(false)
  const searchParams = useSearchParams()
  const router = useRouter()
  const pathName = usePathname()

  const [internalTask, setInternalTask] = useState<SelectTask | undefined>(
    selectedTask
  )

  const [loading, taskData, error, fetchTaskById] =
    useServerAction(GetTaskByIdAction)

  useEffect(() => {
    if (searchParams.get("task_id")) {
      setTaskIdFromUrl(searchParams.get("task_id"))
    }
  }, [searchParams])

  const fetchTask = async (taskId: string) => {
    try {
      const res = await fetchTaskById(taskId)
      if (res?.data) {
        setInternalTask(res.data)
        setSelectedTask(res.data)
        setIsTaskModelOpen(true)
      } else {
        toast({ title: "Task not found" })
        router.replace(pathName)
      }
    } catch (err) {
      console.error("Error fetching task:", err)
      toast({ title: "Failed to fetch task" })
      router.replace(pathName)
    }
  }

  useEffect(() => {
    if (!isReady) return

    // Skip only if this task is already open; a stale task from the store
    // (e.g. after browser back) still needs to be fetched and reopened
    if (
      !taskIdFromUrl ||
      (isTaskModelOpen && internalTask?.id === taskIdFromUrl)
    )
      return

    fetchTask(taskIdFromUrl)
  }, [taskIdFromUrl, isReady])

  // Reset global task state when leaving the page (e.g. via breadcrumb) so it
  // doesn't leak into the next mount
  useEffect(() => {
    return () => {
      setSelectedTask(null)
      setIsTaskModelOpen(false)
    }
  }, [])

  useEffect(() => {
    if (selectedTask) {
      setInternalTask(selectedTask)
    }
  }, [selectedTask])

  useEffect(() => {
    if (isTaskModelOpen && internalTask?.id) {
      const newSearchParams = new URLSearchParams(searchParams.toString())
      newSearchParams.set("task_id", internalTask?.id)

      router.push(`${pathName}?${newSearchParams.toString()}`)
    }
  }, [isTaskModelOpen, internalTask?.id])

  const { showConfirmation, setShowConfirmation, handleClose } =
    useConfirmClose({
      isDirty: isChanged,
      onClose: () => {
        setIsTaskModelOpen(false)
        setInternalTask(undefined)
        setSelectedTask(null)
        setIsChanged(false)

        const newSearchParams = new URLSearchParams(searchParams.toString())
        newSearchParams.delete("task_id")

        setTimeout(() => {
          router.push(`${pathName}?${newSearchParams.toString()}`)
        }, 0)
      }
    })

  const isLoading = createTaskLoading || updateTaskLoading || loading

  return (
    <>
      <Dialog open={isTaskModelOpen} onOpenChange={handleClose}>
        <DialogContent
          className="w-[95vw] max-w-[95vw] sm:max-w-5xl max-h-[95vh] overflow-y-auto overflow-x-hidden lg:overflow-y-hidden p-2 sm:p-6 gap-2 sm:gap-4 [&>button]:w-5 [&>button]:h-5 sm:[&>button]:w-6 sm:[&>button]:h-6 [&>button>svg]:w-5 [&>button>svg]:h-5 sm:[&>button>svg]:w-6 sm:[&>button>svg]:h-6"
          onInteractOutside={(e) => e.preventDefault()}
        >
          <DialogHeader>
            <TaskFormHeader
              selectedTask={internalTask}
              onClose={() => handleClose(false)}
            />
            <DialogTitle className="sr-only">
              {internalTask
                ? `Edit Task: ${internalTask.task_title}`
                : "Create New Task"}
            </DialogTitle>
          </DialogHeader>

          <TaskForm
            statuses={statuses}
            onSubmit={handleSubmit}
            selectedTask={internalTask}
            loading={isLoading}
            isTaskModelOpen={isTaskModelOpen}
            setIsChanged={setIsChanged}
            onSubTaskCreate={onSubTaskCreate}
            isSprintCompleted={isSprintCompleted}
            refetchComments={refetchComments}
            setRefetchComments={setRefetchComments}
            verificationStatus={verificationStatus}
            onVerificationStatusChange={onVerificationStatusChange}
          />
        </DialogContent>
      </Dialog>

      <UnsavedChangesDialog
        showConfirmation={showConfirmation}
        setShowConfirmation={setShowConfirmation}
        setIsActualDialogOpen={setIsTaskModelOpen}
      />
    </>
  )
}
