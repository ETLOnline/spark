"use client"
import { Button } from "@/src/components/ui/button"
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle
} from "@/src/components/ui/card"
import { ScrollArea, ScrollBar } from "@/src/components/ui/scroll-area"
import { useState } from "react"
import { useAtom } from "jotai"
import { spaceStore } from "@/src/store/space/spaceStore"

const CategorySelection = () => {
  const [categories, setCategories] = useState([
    "All",
    "Programming",
    "AI & Machine Learning",
    "Open Source",
    "Web Development",
    "Mobile Development",
    "Data Science",
    "DevOps",
    "Cybersecurity",
    "Blockchain",
    "IoT"
  ])

  const [activeCategory, setActiveCategory] = useAtom(spaceStore.activeCategory)

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle>Categories</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="w-full overflow-auto pb-3">
          <div className="flex w-[100px] space-x-2 p-1">
            {categories.map((category) => (
              <Button
                key={category}
                variant={activeCategory === category ? "default" : "outline"}
                onClick={() => setActiveCategory(category)}
                className="flex-shrink-0"
              >
                {category}
              </Button>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </CardContent>
    </Card>
  )
}

export default CategorySelection
