"use client"

import { useCallback, useEffect, useState } from "react"
import { ChevronRight, Plus } from "lucide-react"
import { Button } from "@/src/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle
} from "../../ui/dialog"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle
} from "../../ui/sheet"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle
} from "../../ui/alert-dialog"
import { useServerAction } from "@/src/hooks/useServerAction"
import {
  CreateSessionRequestAction,
  DeleteSessionRequestsForRemovedSlotAction,
  GetAcceptedSessionRequestsForMentorAction,
  GetMentorAvailabilityAction,
  GetMySessionRequestsForMentorAction,
  GetPendingSessionRequestsForMentorAction,
  NotifySlotTimeChangedAction,
  ResubmitSessionRequestAction,
  UpdateAvailabilityAction
} from "@/src/server-actions/Mentor/MentorActions"
import { AuthUserAction } from "@/src/server-actions/User/AuthUserAction"
import { GetUserRewardBalanceAction } from "@/src/server-actions/Reward/Reward"
import { getFeatureFlagAction } from "@/src/server-actions/FeatureFlag/FeatureFlag"
import { toast } from "@/src/hooks/use-toast"
import { SelectMentorAvailability, SelectSessionRequest } from "@/src/db/schema"
import moment from "moment-timezone"
import {
  DAY_HEADERS,
  DAYS,
  MENTORSHIP_RP_THRESHOLD_ENABLED,
  REPUTATION_POINTS_REWARD_ID
} from "@/src/utils/constants"
import { MIN_DURATION_MINS, toMins } from "@/src/utils/time"
import {
  endOfMonth,
  getDurationOptions,
  getAcceptedOccurrenceDatesForSlot,
  getSlotsForDate,
  getStartTimeOptions,
  getUnavailableRangesForRequest,
  isPastDate,
  minsToTime,
  nextOccurrence,
  pendingOnlyRequestsFor,
  pendingRequestsOverlappingSlot,
  RepeatType,
  SessionType
} from "./mentor-calendar/mentorCalendarUtils"
import { MentorCalendarGrid } from "./mentor-calendar/MentorCalendarGrid"
import { SlotListItem } from "./mentor-calendar/SlotListItem"
import { SessionRequestForm } from "./mentor-calendar/SessionRequestForm"
import { AvailabilitySlotForm } from "./mentor-calendar/AvailabilitySlotForm"
import SuggestNewSlotDialog, {
  type RequestWithOptionalMentee
} from "./SuggestNewSlotDialog"

// ── Component ──────────────────────────────────────────────────────────────────

interface MentorCalendarProps {
  userId: string
  isMyProfile?: boolean
}

// Stable reference — computed once at module load, not on every render
const TODAY = moment().startOf("day").toDate()

export function MentorCalendar({
  userId,
  isMyProfile = false
}: MentorCalendarProps) {
  const today = TODAY

  const [slots, setSlots] = useState<SelectMentorAvailability[]>([])

  // Popup state
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [isListOpen, setIsListOpen] = useState(false)
  const [isSlotFormOpen, setIsSlotFormOpen] = useState(false)
  const [editingSlotId, setEditingSlotId] = useState<number | null>(null)
  const [editingScope, setEditingScope] = useState<"series" | "occurrence">(
    "series"
  )
  const [editingOccurrenceDate, setEditingOccurrenceDate] = useState<
    string | null
  >(null)
  const [newDate, setNewDate] = useState(moment(today).format("YYYY-MM-DD"))
  const [newStart, setNewStart] = useState("09:00")
  const [newEnd, setNewEnd] = useState("10:00")
  const [newSession, setNewSession] = useState<SessionType>("1:1")
  const [newRepeat, setNewRepeat] = useState<RepeatType>("weekly")
  const [newRepeatDays, setNewRepeatDays] = useState<number[]>([today.getDay()])
  const [newRepeatEnd, setNewRepeatEnd] = useState("")
  const [slotError, setSlotError] = useState("")
  const [saving, setSaving] = useState(false)
  const [pendingDeleteId, setPendingDeleteId] = useState<number | null>(null)
  const [pendingEditId, setPendingEditId] = useState<number | null>(null)

  // RP threshold feature flag
  const [rpThresholdEnabled, setRpThresholdEnabled] = useState(false)
  const [rpThresholdValue, setRpThresholdValue] = useState("")
  const [, , , GetFeatureFlag] = useServerAction(getFeatureFlagAction)

  // Request-a-session form state (viewer only)
  const [viewerRp, setViewerRp] = useState(0)
  const [myRequests, setMyRequests] = useState<SelectSessionRequest[]>([])
  const [requestFormSlot, setRequestFormSlot] =
    useState<SelectMentorAvailability | null>(null)
  const [requestStartTime, setRequestStartTime] = useState("")
  const [requestDuration, setRequestDuration] = useState(60)
  const [requestTopic, setRequestTopic] = useState("")
  const [requestDescription, setRequestDescription] = useState("")
  const [requestRecurring, setRequestRecurring] = useState(false)
  const [requestRepeatEndDate, setRequestRepeatEndDate] = useState("")
  const [requestError, setRequestError] = useState("")
  const [requestSubmitting, setRequestSubmitting] = useState(false)

  const [acceptedRequests, setAcceptedRequests] = useState<
    SelectSessionRequest[]
  >([])
  const [mentorPendingRequests, setMentorPendingRequests] = useState<
    RequestWithOptionalMentee[]
  >([])

  // Delete gating — a slot with pending requests can't be deleted until each
  // one has been given an alternative slot suggestion.
  const [deleteGate, setDeleteGate] = useState<{
    mode: "series" | "occurrence"
    slotId: number
    date: Date
    queue: RequestWithOptionalMentee[]
  } | null>(null)
  const [suggestTarget, setSuggestTarget] =
    useState<RequestWithOptionalMentee | null>(null)

  // Edit-time-change gating — editing a slot's time with pending requests on
  // it needs mentor confirmation before saving, since those mentees will be
  // notified their requested time moved.
  const [timeChangeGate, setTimeChangeGate] = useState<
    RequestWithOptionalMentee[] | null
  >(null)

  const [, , , getAvailability] = useServerAction(GetMentorAvailabilityAction)
  const [, , , updateAvailability] = useServerAction(UpdateAvailabilityAction)
  const [, , , notifySlotTimeChanged] = useServerAction(
    NotifySlotTimeChangedAction
  )
  const [, , , getAuthUser] = useServerAction(AuthUserAction)
  const [, , , getViewerRpBalance] = useServerAction(GetUserRewardBalanceAction)
  const [, , , getMyRequests] = useServerAction(
    GetMySessionRequestsForMentorAction
  )
  const [, , , createSessionRequest] = useServerAction(
    CreateSessionRequestAction
  )
  const [resubmitSubmitting, , , resubmitSessionRequest] = useServerAction(
    ResubmitSessionRequestAction
  )
  const [, , , getAcceptedRequests] = useServerAction(
    GetAcceptedSessionRequestsForMentorAction
  )
  const [, , , getMentorPendingRequests] = useServerAction(
    GetPendingSessionRequestsForMentorAction
  )
  const [, , , deleteSessionRequestsForSlot] = useServerAction(
    DeleteSessionRequestsForRemovedSlotAction
  )

  /** Returns the slot_suggested request for this exact slot + date occurrence, if any. */
  const getSuggestedRequestForSlot = (slotId: number, date: Date) => {
    const key = `${slotId}-${moment(date).format("YYYY-MM-DD")}`
    return (
      myRequests.find(
        (r) =>
          r.status === "slot_suggested" &&
          ((r.suggested_slot_ids ?? []) as unknown as string[]).includes(key)
      ) ?? null
    )
  }

  const loadSlots = useCallback(async () => {
    const res = await getAvailability(userId)
    if (res?.success) setSlots((res.data ?? []).filter((s) => s.is_active))
  }, [userId])

  useEffect(() => {
    loadSlots()
  }, [loadSlots])

  const loadMyRequests = useCallback(async () => {
    const myRequestRes = await getMyRequests(userId)
    if (myRequestRes?.success) setMyRequests(myRequestRes.data ?? [])
  }, [userId])

  const loadAcceptedRequests = useCallback(async () => {
    const res = await getAcceptedRequests(userId)
    if (res?.success)
      setAcceptedRequests((res.data as SelectSessionRequest[]) ?? [])
  }, [userId])

  const loadMentorPendingRequests = useCallback(async () => {
    const res = await getMentorPendingRequests(userId)
    if (res?.success)
      setMentorPendingRequests((res.data as RequestWithOptionalMentee[]) ?? [])
  }, [userId])

  useEffect(() => {
    loadAcceptedRequests()
    if (isMyProfile) {
      loadMentorPendingRequests()
      return
    }
    const fetchViewerContext = async () => {
      const authUser = await getAuthUser()
      if (!authUser) return
      const balanceRes = await getViewerRpBalance(
        authUser.unique_id,
        REPUTATION_POINTS_REWARD_ID
      )
      if (balanceRes?.success) {
        setViewerRp(balanceRes.data?.current_balance ?? 0)
      }

      const rpData = (await GetFeatureFlag([MENTORSHIP_RP_THRESHOLD_ENABLED]))
        ?.data
      if (rpData) {
        setRpThresholdEnabled(!!rpData.is_enabled)
        if (rpData.value) setRpThresholdValue(rpData.value)
      }
    }
    fetchViewerContext()
    loadMyRequests()
  }, [
    isMyProfile,
    loadMyRequests,
    loadAcceptedRequests,
    loadMentorPendingRequests
  ])

  const resetPopupForm = (date: Date) => {
    setPendingDeleteId(null)
    setPendingEditId(null)
    setRequestFormSlot(null)
    setRequestError("")
    const dateStr = moment(date).format("YYYY-MM-DD")
    setNewDate(dateStr)
    setNewStart("09:00")
    setNewEnd("10:00")
    setNewSession("1:1")
    setNewRepeat("weekly")
    setNewRepeatDays([date.getDay()])
    setNewRepeatEnd(endOfMonth(dateStr))
    setSlotError("")
  }

  const openPopup = (date: Date) => {
    if (
      !isMyProfile &&
      (getSlotsForDate(slots, date).length === 0 || isPastDate(date))
    )
      return
    setSelectedDate(date)
    resetPopupForm(date)
    setIsListOpen(true)
  }

  /** The list Sheet and the Add/Edit/Request Dialogs all sit on Radix's
   * Dialog.Root primitive. Closing one and opening another in the same tick
   * races Radix's exit-animation/body-lock cleanup and can leave the page
   * stuck (unresponsive clicks, a frozen overlay). Always close whatever is
   * open first, then open the next one only after the close animation has
   * actually finished. */
  const OVERLAY_TRANSITION_MS = 320

  const switchOverlay = (openNext: () => void) => {
    setIsListOpen(false)
    setIsSlotFormOpen(false)
    setRequestFormSlot(null)
    setTimeout(openNext, OVERLAY_TRANSITION_MS)
  }

  /** Opens the Add/Edit slot dialog on top of (in place of) the list sheet. */
  const openAddSlot = () => {
    const date = selectedDate ?? today
    resetPopupForm(date)
    setEditingSlotId(null)
    setEditingScope("series")
    setEditingOccurrenceDate(null)
    switchOverlay(() => setIsSlotFormOpen(true))
  }

  /** Edits the whole recurring series (or the sole date of a one-off slot). */
  const openEditSlot = (slot: SelectMentorAvailability) => {
    setNewDate(slot.date)
    setNewStart(slot.start_time)
    setNewEnd(slot.end_time)
    setNewSession(slot.session_type as SessionType)
    setNewRepeat(slot.repeat_type as RepeatType)
    setNewRepeatDays([moment(slot.date, "YYYY-MM-DD").day()])
    setNewRepeatEnd(slot.repeat_end_date ?? "")
    setSlotError("")
    setEditingSlotId(slot.id)
    setEditingScope("series")
    setEditingOccurrenceDate(null)
    setPendingEditId(null)
    switchOverlay(() => setIsSlotFormOpen(true))
  }

  /** Edits only the single occurrence on `date`, splitting it out of the
   * recurring series so the rest of the series is unaffected. */
  const openEditOccurrence = (slot: SelectMentorAvailability, date: Date) => {
    const occStr = moment(date).format("YYYY-MM-DD")
    setNewDate(occStr)
    setNewStart(slot.start_time)
    setNewEnd(slot.end_time)
    setNewSession(slot.session_type as SessionType)
    setNewRepeat("none")
    setNewRepeatDays([date.getDay()])
    setNewRepeatEnd("")
    setSlotError("")
    setEditingSlotId(slot.id)
    setEditingScope("occurrence")
    setEditingOccurrenceDate(occStr)
    setPendingEditId(null)
    switchOverlay(() => setIsSlotFormOpen(true))
  }

  /** Closes the Add/Edit dialog and returns to the list sheet. */
  const closeSlotForm = () => {
    setEditingSlotId(null)
    setEditingScope("series")
    setEditingOccurrenceDate(null)
    switchOverlay(() => setIsListOpen(true))
  }

  const handleAddSlot = async (skipTimeChangeGate = false) => {
    const anchorStart = moment(`${newDate} ${newStart}`, "YYYY-MM-DD HH:mm")
    if (anchorStart.isBefore(moment())) {
      setSlotError("Cannot add availability in the past")
      return
    }
    if (toMins(newEnd) <= toMins(newStart)) {
      setSlotError("End time must be after start time")
      return
    }
    if (toMins(newEnd) - toMins(newStart) < MIN_DURATION_MINS) {
      setSlotError(`Minimum ${MIN_DURATION_MINS} minutes`)
      return
    }
    if (newRepeat === "weekly" && newRepeatDays.length === 0) {
      setSlotError("Select at least one day")
      return
    }

    // When editing, exclude the slot being edited from its own overlap check
    const otherSlots = editingSlotId
      ? slots.filter((s) => s.id !== editingSlotId)
      : slots

    // Overlap check — slots conflict if they share a day, overlapping times, AND overlapping date ranges
    const timesOverlap = (s: SelectMentorAvailability) =>
      toMins(newStart) < toMins(s.end_time) &&
      toMins(s.start_time) < toMins(newEnd)

    const dayOverlaps = (s: SelectMentorAvailability, dow: number) => {
      const sDow = moment(s.date, "YYYY-MM-DD").day()
      if (s.repeat_type === "daily") return true
      if (s.repeat_type === "none") {
        if (newRepeat === "none") return s.date === newDate
        if (newRepeat === "daily") return true
        if (newRepeat === "weekly") return sDow === dow
      }
      if (s.repeat_type === "weekly") {
        if (newRepeat === "none")
          return sDow === moment(newDate, "YYYY-MM-DD").day()
        if (newRepeat === "daily") return true
        if (newRepeat === "weekly") return sDow === dow
      }
      return false
    }

    const dateRangesOverlap = (s: SelectMentorAvailability, dow: number) => {
      const existingStart = s.date
      // A one-time slot only occupies its own date — it doesn't repeat, so
      // it must not be treated as extending indefinitely into the future.
      const existingEnd =
        s.repeat_type === "none" ? s.date : (s.repeat_end_date ?? "9999-12-31")
      const newFirst =
        newRepeat === "weekly" ? nextOccurrence(newDate, dow) : newDate
      const newLast =
        newRepeat !== "none" ? newRepeatEnd || endOfMonth(newDate) : newDate
      return newFirst <= existingEnd && existingStart <= newLast
    }

    const hasConflict = (dow: number) =>
      otherSlots.some(
        (s) =>
          dayOverlaps(s, dow) && timesOverlap(s) && dateRangesOverlap(s, dow)
      )

    if (newRepeat === "weekly") {
      const conflicting = newRepeatDays
        .filter((dow) => hasConflict(dow))
        .map((dow) => DAY_HEADERS[dow])
      if (conflicting.length > 0) {
        setSlotError(`Overlapping slot exists for: ${conflicting.join(", ")}`)
        return
      }
    } else {
      if (hasConflict(moment(newDate, "YYYY-MM-DD").day())) {
        setSlotError("This slot overlaps with an existing one")
        return
      }
    }

    // Editing a slot with pending requests on it moves the time for whoever
    // requested it — confirm with the mentor before saving, once, then
    // proceed straight through on the retry (skipTimeChangeGate).
    const originalSlot = editingSlotId
      ? slots.find((s) => s.id === editingSlotId)
      : undefined
    const affectedPendingRequests = originalSlot
      ? editingScope === "occurrence" && editingOccurrenceDate
        ? pendingOnlyRequestsFor(
            originalSlot,
            moment(editingOccurrenceDate, "YYYY-MM-DD").toDate(),
            mentorPendingRequests
          )
        : pendingRequestsOverlappingSlot(originalSlot, mentorPendingRequests)
      : []

    if (!skipTimeChangeGate && affectedPendingRequests.length > 0) {
      setTimeChangeGate(affectedPendingRequests)
      return
    }

    setSaving(true)
    const repeatEnd =
      newRepeat !== "none" ? newRepeatEnd || endOfMonth(newDate) : null

    const newSlots =
      newRepeat === "weekly"
        ? newRepeatDays.map((dow) => ({
            date: nextOccurrence(newDate, dow),
            start_time: newStart,
            end_time: newEnd,
            session_type: newSession,
            repeat_type: "weekly" as RepeatType,
            repeat_end_date: repeatEnd
          }))
        : [
            {
              date: newDate,
              start_time: newStart,
              end_time: newEnd,
              session_type: newSession,
              repeat_type: newRepeat,
              repeat_end_date: repeatEnd
            }
          ]

    const existing = serializeSlots(otherSlots)

    // Editing a single occurrence: keep the rest of the original series by
    // splicing it around the date being edited (same split used on delete).
    const seriesRemnants =
      editingScope === "occurrence" && originalSlot && editingOccurrenceDate
        ? splitSeriesExcludingDate(
            originalSlot,
            moment(editingOccurrenceDate, "YYYY-MM-DD").toDate()
          )
        : []

    const res = await updateAvailability({
      mentorId: userId,
      slots: [...existing, ...seriesRemnants, ...newSlots]
    })
    if (res?.success) {
      setSlotError("")
      await loadSlots()
      closeSlotForm()
      toast({
        title: editingSlotId ? "Slot updated" : "Slot added",
        duration: 2000
      })
      if (affectedPendingRequests.length > 0) {
        await notifySlotTimeChanged({
          requestIds: affectedPendingRequests.map((r) => r.id)
        })
        await loadMentorPendingRequests()
      }
    } else {
      toast({
        title: editingSlotId ? "Failed to update slot" : "Failed to add slot",
        variant: "destructive",
        duration: 2000
      })
    }
    setSaving(false)
  }

  const confirmTimeChangeAndSave = () => {
    setTimeChangeGate(null)
    handleAddSlot(true)
  }

  const cancelTimeChange = () => setTimeChangeGate(null)

  const openRequestForm = (slot: SelectMentorAvailability) => {
    setRequestTopic("")
    setRequestDescription("")
    setRequestRecurring(false)
    setRequestRepeatEndDate(slot.repeat_end_date ?? "")
    setRequestError("")
    const unavailable = selectedDate
      ? getUnavailableRangesForRequest(
          slot,
          selectedDate,
          myRequests,
          acceptedRequests
        )
      : []
    const startOptions = getStartTimeOptions(slot, unavailable)
    const firstStart = startOptions[0] ?? slot.start_time
    setRequestStartTime(firstStart)
    const fitting = getDurationOptions(slot, firstStart, unavailable)
    setRequestDuration(fitting[0] ?? MIN_DURATION_MINS)
    switchOverlay(() => setRequestFormSlot(slot))
  }

  const confirmSuggestedSlot = async (
    slot: SelectMentorAvailability,
    requestId: number
  ) => {
    if (!selectedDate) return
    const res = await resubmitSessionRequest({
      requestId,
      slotId: slot.id,
      sessionDate: moment(selectedDate).format("YYYY-MM-DD"),
      startTime: slot.start_time,
      endTime: slot.end_time
    })
    if (res?.success) {
      await loadMyRequests()
      setIsListOpen(false)
      toast({ title: "Session request resubmitted", duration: 2000 })
    } else {
      toast({
        variant: "destructive",
        title: "Failed to resubmit",
        description: res?.error ?? "Please try again.",
        duration: 3000
      })
    }
  }

  /** Closes the Request-a-Session dialog and returns to the list sheet. */
  const closeRequestForm = () => {
    switchOverlay(() => setIsListOpen(true))
  }

  const handleRequestStartTimeChange = (value: string) => {
    setRequestStartTime(value)
    if (!requestFormSlot || !selectedDate) return
    const unavailable = getUnavailableRangesForRequest(
      requestFormSlot,
      selectedDate,
      myRequests,
      acceptedRequests
    )
    const fitting = getDurationOptions(requestFormSlot, value, unavailable)
    if (!fitting.includes(requestDuration)) {
      setRequestDuration(fitting[0] ?? MIN_DURATION_MINS)
    }
  }

  const handleSubmitRequest = async () => {
    if (!requestFormSlot || !selectedDate) return
    if (!requestTopic.trim()) {
      setRequestError("Topic is required")
      return
    }

    const recurring = requestFormSlot.repeat_type !== "none" && requestRecurring

    setRequestSubmitting(true)
    const res = await createSessionRequest({
      mentorId: userId,
      availabilitySlotId: requestFormSlot.id,
      sessionDate: moment(selectedDate).format("YYYY-MM-DD"),
      startTime: requestStartTime,
      endTime: minsToTime(toMins(requestStartTime) + requestDuration),
      topic: requestTopic,
      description: requestDescription,
      recurring,
      repeatEndDate: recurring ? requestRepeatEndDate || null : null
    })
    setRequestSubmitting(false)

    if (res?.success) {
      await loadMyRequests()
      closeRequestForm()
      toast({ title: "Session request sent", duration: 2000 })
    } else {
      setRequestError(res?.error ?? "Failed to send request")
    }
  }

  const serializeSlots = (list: SelectMentorAvailability[]) =>
    list.map((s) => ({
      date: s.date,
      start_time: s.start_time,
      end_time: s.end_time,
      session_type: s.session_type,
      repeat_type: s.repeat_type,
      repeat_end_date: s.repeat_end_date ?? null
    }))

  /** Splits a recurring series around `date`, returning the serialized
   * before/after remnants that keep every other occurrence intact. */
  const splitSeriesExcludingDate = (
    slot: SelectMentorAvailability,
    date: Date
  ) => {
    const dow = moment(slot.date, "YYYY-MM-DD").day()
    const occStr = moment(date).format("YYYY-MM-DD")

    // Day before this occurrence → previous series ends here
    const prevStr = moment(date).subtract(1, "day").format("YYYY-MM-DD")

    // Day after this occurrence → next series starts here
    const afterStr = moment(date).add(1, "day").format("YYYY-MM-DD")
    const nextStr =
      slot.repeat_type === "daily" ? afterStr : nextOccurrence(afterStr, dow)

    const additions: ReturnType<typeof serializeSlots> = []

    // Keep everything BEFORE this occurrence (only if anchor < occurrence)
    if (slot.date < occStr) {
      additions.push({
        date: slot.date,
        start_time: slot.start_time,
        end_time: slot.end_time,
        session_type: slot.session_type,
        repeat_type: slot.repeat_type,
        repeat_end_date: prevStr
      })
    }

    // Keep everything AFTER this occurrence (only if a next occurrence exists within the original end)
    const originalEnd = slot.repeat_end_date ?? null
    if (!originalEnd || nextStr <= originalEnd) {
      additions.push({
        date: nextStr,
        start_time: slot.start_time,
        end_time: slot.end_time,
        session_type: slot.session_type,
        repeat_type: slot.repeat_type,
        repeat_end_date: originalEnd
      })
    }

    return additions
  }

  /** Remove the entire recurring series (or a one-time slot) — any occurrence
   * date that already has an accepted booking is kept alive as a standalone
   * one-time slot so the mentee doesn't lose their confirmed session. */
  const performDeleteSeries = async (slotId: number) => {
    setPendingDeleteId(null)
    setSlotError("")
    const slot = slots.find((s) => s.id === slotId)
    if (!slot) return

    const bookedDates = getAcceptedOccurrenceDatesForSlot(
      slot,
      acceptedRequests
    )
    const preserved = bookedDates.map((date) => ({
      date,
      start_time: slot.start_time,
      end_time: slot.end_time,
      session_type: slot.session_type,
      repeat_type: "none" as RepeatType,
      repeat_end_date: null
    }))

    const remaining = serializeSlots(slots.filter((s) => s.id !== slotId))
    const res = await updateAvailability({
      mentorId: userId,
      slots: [...remaining, ...preserved]
    })
    if (res?.success) {
      await deleteSessionRequestsForSlot({
        mentorId: userId,
        startTime: slot.start_time,
        endTime: slot.end_time
      })
      setSlots([])
      await loadSlots()
      if (selectedDate) resetPopupForm(selectedDate)
      toast({
        title:
          bookedDates.length > 0 ? "Unbooked slots removed" : "Slot removed",
        description:
          bookedDates.length > 0
            ? "Dates with an accepted booking were kept."
            : undefined,
        duration: 2500
      })
    }
  }

  /** Remove only the occurrence on `date`, keeping the rest of the series intact. */
  const performDeleteOccurrence = async (slotId: number, date: Date) => {
    setPendingDeleteId(null)
    setSlotError("")
    const slot = slots.find((s) => s.id === slotId)
    if (!slot) return

    const occStr = moment(date).format("YYYY-MM-DD")
    const otherSlots = serializeSlots(slots.filter((s) => s.id !== slotId))
    const additions = splitSeriesExcludingDate(slot, date)

    const res = await updateAvailability({
      mentorId: userId,
      slots: [...otherSlots, ...additions]
    })
    if (res?.success) {
      await deleteSessionRequestsForSlot({
        mentorId: userId,
        startTime: slot.start_time,
        endTime: slot.end_time,
        sessionDate: occStr
      })
      setSlots([])
      await loadSlots()
      if (selectedDate) resetPopupForm(selectedDate)
      toast({ title: "Occurrence removed", duration: 2000 })
    }
  }

  /** Entry point wired to SlotListItem — blocks deletion behind the
   * suggest-new-slot flow if a pending request overlaps this occurrence. */
  const handleDeleteSeries = (slotId: number) => {
    const slot = slots.find((s) => s.id === slotId)
    if (!slot || !selectedDate) return
    const pending = pendingOnlyRequestsFor(
      slot,
      selectedDate,
      mentorPendingRequests
    )
    if (pending.length > 0) {
      setDeleteGate({
        mode: "series",
        slotId,
        date: selectedDate,
        queue: pending
      })
      return
    }
    performDeleteSeries(slotId)
  }

  /** Entry point wired to SlotListItem — same gating as handleDeleteSeries,
   * scoped to a single occurrence date. */
  const handleDeleteOccurrence = (slotId: number, date: Date) => {
    const slot = slots.find((s) => s.id === slotId)
    if (!slot) return
    const pending = pendingOnlyRequestsFor(slot, date, mentorPendingRequests)
    if (pending.length > 0) {
      setDeleteGate({ mode: "occurrence", slotId, date, queue: pending })
      return
    }
    performDeleteOccurrence(slotId, date)
  }

  /** A suggestion was sent for one of the gated requests — drop it from the
   * list shown in the gate dialog. The slot itself is only deleted once the
   * mentor explicitly clicks "Delete Slot" with an empty queue. */
  const handleSuggestedForGatedDelete = async (requestId: number) => {
    setSuggestTarget(null)
    await loadMentorPendingRequests()
    setDeleteGate((gate) =>
      gate
        ? { ...gate, queue: gate.queue.filter((r) => r.id !== requestId) }
        : null
    )
  }

  const handleConfirmGatedDelete = () => {
    if (!deleteGate || deleteGate.queue.length > 0) return
    if (deleteGate.mode === "series") {
      performDeleteSeries(deleteGate.slotId)
    } else {
      performDeleteOccurrence(deleteGate.slotId, deleteGate.date)
    }
    setDeleteGate(null)
  }

  // ── Derived values ────────────────────────────────────────────────────────────

  const slotsForSelected = selectedDate
    ? getSlotsForDate(slots, selectedDate)
    : []
  const selectedDayName = selectedDate ? DAYS[selectedDate.getDay()] : ""

  // ── Render ────────────────────────────────────────────────────────────────────

  return (
    <div className="flex flex-col h-full overflow-hidden">
      <MentorCalendarGrid
        today={today}
        slots={slots}
        isMyProfile={isMyProfile}
        myRequests={myRequests}
        bookedRequests={acceptedRequests}
        mentorPendingRequests={mentorPendingRequests}
        mentorAcceptedRequests={acceptedRequests}
        onSelectDate={openPopup}
      />

      {/* ── List sheet — slides in from the right ── */}
      <Sheet open={isListOpen} onOpenChange={setIsListOpen}>
        <SheetContent
          onInteractOutside={(e) => e.preventDefault()}
          className="w-full sm:max-w-[420px] p-0 gap-0 flex flex-col"
        >
          <SheetHeader className="px-5 pt-5 pb-3 shrink-0 text-left">
            <SheetTitle className="text-lg font-semibold">
              {isMyProfile
                ? "Manage Availability"
                : `${selectedDayName} Availability`}
            </SheetTitle>
            {selectedDate && (
              <SheetDescription>
                {moment(selectedDate).format("dddd, MMMM D, YYYY")}
              </SheetDescription>
            )}
          </SheetHeader>

          <div className="flex-1 overflow-y-auto px-5 pb-3 space-y-3">
            {isMyProfile && (
              <Button
                variant="outline"
                className="w-full h-9 text-sm rounded-lg"
                onClick={openAddSlot}
              >
                <Plus className="h-4 w-4 mr-1.5" />
                Add Slot
              </Button>
            )}

            {/* Slot list */}
            {slotsForSelected.length > 0 && (
              <div className="pt-1 space-y-1.5">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  {isMyProfile
                    ? "Existing Slots"
                    : selectedDate &&
                        slotsForSelected.some(
                          (s) =>
                            getSuggestedRequestForSlot(s.id, selectedDate) !==
                            null
                        )
                      ? "Suggested Slots"
                      : `Available Slot${slotsForSelected.length > 1 ? "s" : ""}`}
                  {slotsForSelected.length > 0 && (
                    <span className="ml-1.5 normal-case font-normal text-foreground">
                      ({slotsForSelected.length})
                    </span>
                  )}
                </p>
                <div className="space-y-1.5">
                  {slotsForSelected.map((slot) => (
                    <SlotListItem
                      key={slot.id}
                      slot={slot}
                      isMyProfile={isMyProfile}
                      selectedDate={selectedDate!}
                      myRequests={myRequests}
                      bookedRequests={acceptedRequests}
                      mentorPendingRequests={mentorPendingRequests}
                      mentorAcceptedRequests={acceptedRequests}
                      viewerRp={viewerRp}
                      rpThresholdEnabled={rpThresholdEnabled}
                      rpThresholdValue={rpThresholdValue}
                      pendingDeleteId={pendingDeleteId}
                      onTogglePendingDelete={(id) => {
                        setPendingEditId(null)
                        setPendingDeleteId(id)
                      }}
                      onDeleteSeries={handleDeleteSeries}
                      onDeleteOccurrence={handleDeleteOccurrence}
                      pendingEditId={pendingEditId}
                      onTogglePendingEdit={(id) => {
                        setPendingDeleteId(null)
                        setPendingEditId(id)
                      }}
                      onEditSlot={openEditSlot}
                      onEditOccurrence={openEditOccurrence}
                      onRequestSlot={openRequestForm}
                      suggestedRequest={getSuggestedRequestForSlot(
                        slot.id,
                        selectedDate!
                      )}
                      isConfirming={resubmitSubmitting}
                      onConfirmSuggestedSlot={confirmSuggestedSlot}
                    />
                  ))}
                </div>
              </div>
            )}

            {!isMyProfile && slotsForSelected.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">
                No availability set for this day
              </p>
            )}
          </div>

          <SheetFooter className="px-5 py-4 border-t border-foreground/8 shrink-0">
            <Button
              variant={isMyProfile ? "outline" : "default"}
              onClick={() => setIsListOpen(false)}
              className="h-9 px-5 text-sm rounded-lg"
            >
              Close
            </Button>
          </SheetFooter>
        </SheetContent>
      </Sheet>

      {/* ── Add/Edit slot dialog (mentor only) ── */}
      <Dialog
        open={isSlotFormOpen}
        onOpenChange={(open) => !open && closeSlotForm()}
      >
        <DialogContent
          onInteractOutside={(e) => e.preventDefault()}
          className="sm:max-w-[420px] p-0 gap-0 flex flex-col max-h-[90dvh]"
        >
          <DialogHeader className="px-5 pt-5 pb-3 shrink-0">
            <DialogTitle className="text-lg font-semibold">
              {!editingSlotId
                ? "New Availability Slot"
                : editingScope === "occurrence"
                  ? "Edit This Date"
                  : "Edit Availability Slot"}
            </DialogTitle>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto px-5 pb-3 space-y-3">
            <AvailabilitySlotForm
              today={today}
              newDate={newDate}
              onDateChange={setNewDate}
              newStart={newStart}
              onStartChange={setNewStart}
              newEnd={newEnd}
              onEndChange={setNewEnd}
              newSession={newSession}
              onSessionChange={setNewSession}
              newRepeat={newRepeat}
              onRepeatChange={setNewRepeat}
              newRepeatDays={newRepeatDays}
              onRepeatDaysChange={setNewRepeatDays}
              newRepeatEnd={newRepeatEnd}
              onRepeatEndChange={setNewRepeatEnd}
              slotError={slotError}
              onClearSlotError={() => setSlotError("")}
              hideRepeat={editingScope === "occurrence"}
            />
          </div>

          <div className="flex items-center justify-end gap-2 px-5 py-4 border-t border-foreground/8 shrink-0">
            <Button
              variant="outline"
              onClick={closeSlotForm}
              className="h-9 px-5 text-sm rounded-lg"
            >
              Cancel
            </Button>
            <Button
              onClick={() => handleAddSlot()}
              loading={saving}
              className="h-9 px-5 text-sm rounded-lg"
            >
              Save
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Pending-request confirmation for edits ── */}
      <AlertDialog
        open={!!timeChangeGate}
        onOpenChange={(open) => !open && cancelTimeChange()}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Change this time slot?</AlertDialogTitle>
            <AlertDialogDescription>
              {timeChangeGate?.length === 1
                ? "1 student has a pending request"
                : `${timeChangeGate?.length ?? 0} students have pending requests`}{" "}
              on this slot. Changing the time will remove their request and
              notify them so they can resubmit if they're still interested. Do
              you want to continue?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={cancelTimeChange}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction onClick={confirmTimeChangeAndSave}>
              Change Time
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* ── Request-a-session dialog (viewer only) ── */}
      <Dialog
        open={!!requestFormSlot}
        onOpenChange={(open) => !open && closeRequestForm()}
      >
        <DialogContent
          onInteractOutside={(e) => e.preventDefault()}
          className="sm:max-w-[420px] p-0 gap-0 flex flex-col max-h-[90dvh]"
        >
          <DialogHeader className="px-5 pt-5 pb-3 shrink-0">
            <DialogTitle className="text-lg font-semibold">
              Request a Session
            </DialogTitle>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto px-5 pb-3 space-y-3">
            {requestFormSlot && (
              <SessionRequestForm
                slot={requestFormSlot}
                unavailableRanges={
                  selectedDate
                    ? getUnavailableRangesForRequest(
                        requestFormSlot,
                        selectedDate,
                        myRequests,
                        acceptedRequests
                      )
                    : []
                }
                startTime={requestStartTime}
                onStartTimeChange={handleRequestStartTimeChange}
                duration={requestDuration}
                onDurationChange={setRequestDuration}
                topic={requestTopic}
                onTopicChange={(v) => {
                  setRequestTopic(v)
                  setRequestError("")
                }}
                description={requestDescription}
                onDescriptionChange={setRequestDescription}
                recurring={requestRecurring}
                onRecurringChange={setRequestRecurring}
                sessionDateStr={
                  selectedDate ? moment(selectedDate).format("YYYY-MM-DD") : ""
                }
                repeatEndDate={requestRepeatEndDate}
                onRepeatEndDateChange={setRequestRepeatEndDate}
                error={requestError}
              />
            )}
          </div>

          <div className="flex items-center justify-end gap-2 px-5 py-4 border-t border-foreground/8 shrink-0">
            <Button
              variant="outline"
              onClick={closeRequestForm}
              className="h-9 px-5 text-sm rounded-lg"
            >
              Back
            </Button>
            <Button
              onClick={handleSubmitRequest}
              loading={requestSubmitting}
              className="h-9 px-5 text-sm rounded-lg"
            >
              Send Request
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ── Pending-request gate: mentor must suggest an alternative before deleting ── */}
      <Dialog
        open={!!deleteGate}
        onOpenChange={(open) => !open && setDeleteGate(null)}
      >
        <DialogContent className="sm:max-w-[440px]">
          <DialogHeader>
            <DialogTitle>Pending Session Requests</DialogTitle>
            <DialogDescription>
              This slot has pending session requests that need an alternative
              before it can be deleted.
            </DialogDescription>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Select a request below to suggest a different time to the mentee.
          </p>

          <div className="flex flex-col gap-2 max-h-60 overflow-y-auto">
            {deleteGate && deleteGate.queue.length > 0 ? (
              deleteGate.queue.map((r) => (
                <button
                  key={r.id}
                  onClick={() => setSuggestTarget(r)}
                  className="flex items-center gap-3 text-left px-3 py-2.5 rounded-md border border-foreground/10 hover:bg-foreground/[0.03] hover:border-foreground/20 transition-colors group"
                >
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">
                      {r.mentee
                        ? `${r.mentee.first_name} ${r.mentee.last_name}`
                        : "Pending request"}
                    </p>
                    <p className="text-xs text-muted-foreground truncate">
                      {r.topic} ·{" "}
                      {moment(r.session_date, "YYYY-MM-DD").format("MMM D")} ·{" "}
                      {moment(r.start_time, "HH:mm").format("h:mm A")}
                    </p>
                  </div>
                  <span className="text-[10px] font-medium px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-600 shrink-0">
                    Pending
                  </span>
                  <ChevronRight className="h-4 w-4 text-muted-foreground/50 shrink-0 group-hover:text-muted-foreground transition-colors" />
                </button>
              ))
            ) : (
              <p className="text-sm text-muted-foreground text-center py-4">
                No pending requests remaining.
              </p>
            )}
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <Button variant="outline" onClick={() => setDeleteGate(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              disabled={!deleteGate || deleteGate.queue.length > 0}
              onClick={handleConfirmGatedDelete}
            >
              Delete Slot
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <SuggestNewSlotDialog
        open={!!suggestTarget}
        onOpenChange={(open) => !open && setSuggestTarget(null)}
        request={suggestTarget}
        mentorId={userId}
        onSuggested={handleSuggestedForGatedDelete}
      />
    </div>
  )
}
