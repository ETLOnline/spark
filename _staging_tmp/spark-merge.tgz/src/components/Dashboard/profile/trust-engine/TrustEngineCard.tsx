"use client"

import { Info, Zap } from "lucide-react"
import Link from "next/link"
import { Card, CardTitle } from "../../../ui/card"
import { Button } from "../../../ui/button"
import { useCallback, useEffect, useState } from "react"
import { useServerAction } from "@/src/hooks/useServerAction"
import {
  GetUserRewardBalanceAction,
  GetUSerRewardLevelAction
} from "@/src/server-actions/Reward/Reward"
import { SelectUser, SelectUserRewardsLevel } from "@/src/db/schema"
import pusherClient from "@/src/services/realtime/PusherClient"
import { progressPercentHelper } from "@/src/utils/clientHelper"
import { GetUserTopCommunityRankAction } from "@/src/server-actions/Communities/CommunityRanking"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger
} from "../../../ui/tooltip"
import { TrustEngineInfoModal } from "../../../TrustEngine/TrustEngineInfoModal"

interface TrustEngineCardProps {
  user: SelectUser
  isMyProfile?: boolean
}

export default function TrustEngineCard({
  user,
  isMyProfile
}: TrustEngineCardProps) {
  const [userSCPoints, setUserSCPoints] = useState(0)
  const [userRPPoints, setUserRPPoints] = useState(0)
  const [userLevel, setUserLevel] = useState<SelectUserRewardsLevel | null>(
    null
  )
  const [topRank, setTopRank] = useState<{
    rank: number
    community_title: string
  } | null>(null)
  const [isInfoOpen, setIsInfoOpen] = useState(false)

  const [, , , GetUserTopCommunityRank] = useServerAction(
    GetUserTopCommunityRankAction
  )

  const [, , , GetUserRewardBalance] = useServerAction(
    GetUserRewardBalanceAction
  )
  const [, , , GetUserRewardLevel] = useServerAction(GetUSerRewardLevelAction)

  const fetchData = useCallback(async () => {
    const [rpRes, scRes, levelRes, topRankRes] = await Promise.all([
      GetUserRewardBalance(user.unique_id, 1),
      GetUserRewardBalance(user.unique_id, 2),
      GetUserRewardLevel(user.unique_id),
      GetUserTopCommunityRank(user.unique_id)
    ])

    if (scRes?.success && scRes.data)
      setUserSCPoints(scRes.data.current_balance)
    if (rpRes?.success && rpRes.data)
      setUserRPPoints(rpRes.data.current_balance)
    if (levelRes?.success && levelRes.data) setUserLevel(levelRes.data)
    if (topRankRes?.success && topRankRes.data) setTopRank(topRankRes.data)
  }, [user.unique_id])

  useEffect(() => {
    fetchData()
  }, [fetchData])

  const minPoints = userLevel?.rewardLevel?.min_points ?? 0
  const maxPoints = userLevel?.rewardLevel?.max_points ?? 0
  const progressPercent = progressPercentHelper(
    userRPPoints,
    minPoints,
    maxPoints
  )

  const dashboardHref = isMyProfile
    ? "/profile/trust-engine"
    : `/profile/${user.unique_id}/trust-engine`

  return (
    <Card className="rounded-xl border p-4 sm:p-6 shadow-sm spark-gradient-panel-bg">
      {/* Header */}
      <div className="mb-6 flex flex-col sm:flex-row justify-between  gap-2">
        <div className="flex items-center gap-2">
          <Zap className="h-5 w-5 sm:h-6 sm:w-6 text-teal-600 dark:text-teal-400" />
          <CardTitle className="text-xl sm:text-2xl font-bold text-gray-900 dark:text-white">
            Trust Engine
          </CardTitle>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  type="button"
                  onClick={() => setIsInfoOpen(true)}
                  aria-label="How to earn SCs and RPs"
                  className="text-gray-500 hover:text-teal-600 dark:text-gray-400 dark:hover:text-teal-400"
                >
                  <Info className="h-4 w-4 sm:h-5 sm:w-5" />
                </button>
              </TooltipTrigger>
              <TooltipContent>How to earn SCs and RPs</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>

        <Button className="w-full sm:w-auto">
          <Link href={dashboardHref}>View Dashboard</Link>
        </Button>
      </div>

      <TrustEngineInfoModal open={isInfoOpen} onOpenChange={setIsInfoOpen} />

      {/* Stats Grid */}
      <div className="mb-6 sm:mb-8 grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="rounded-lg border p-4 bg-card flex flex-col justify-between h-full">
          <p className="mb-2 text-xs font-medium text-gray-600 dark:text-gray-400">
            Reputation Points
          </p>
          <p className="mb-1 text-2xl font-bold text-teal-600 dark:text-teal-400">
            {userRPPoints}
          </p>

          {/* Todo: for future */}
          {/* <p className="text-xs text-gray-500 dark:text-gray-400">
            +12% this month
          </p> */}
        </div>

        <div className="rounded-lg border p-4 bg-card flex flex-col justify-between h-full">
          <p className="mb-2 text-xs font-medium text-gray-600 dark:text-gray-400">
            Spark Credits
          </p>
          <p className="mb-1 text-2xl font-bold text-purple-600 dark:text-purple-400">
            {userSCPoints}
          </p>
          {/* Todo: for future */}
          {/* <p className="text-xs text-gray-500 dark:text-gray-400">
            Available
          </p> */}
        </div>

        <div className="rounded-lg border p-4 bg-card flex flex-col justify-between h-full relative">
          <p className="mb-2 text-xs font-medium text-gray-600 dark:text-gray-400">
            Current Level
          </p>
          <p
            className="mb-1 font-bold text-teal-600 dark:text-teal-400 line-clamp-2 break-words"
            title={userLevel?.rewardLevel?.name ?? "—"}
          >
            {userLevel?.rewardLevel?.name ?? "—"}
          </p>
          <img
            src={`/images/rewards/levels/compressed/level-${userLevel?.rewardLevel?.id ?? 1}.png`}
            className="absolute -top-4 -right-4 w-12 h-12"
            alt=""
          />
        </div>

        <div className="rounded-lg border p-4 bg-card flex flex-col justify-between h-full">
          <p className="mb-2 text-xs font-medium text-gray-600 dark:text-gray-400">
            Community Rank
          </p>
          <p className="mb-1 text-2xl font-bold text-orange-600 dark:text-orange-400">
            #{topRank?.rank ?? ""}
          </p>
          <p
            className="text-xs text-muted-foreground truncate"
            title={topRank?.community_title}
          >
            {topRank?.community_title}
          </p>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="space-y-2">
        <div className="flex flex-wrap items-center justify-between gap-1 text-sm">
          <span className="font-medium text-gray-700 dark:text-gray-300">
            Progress to Next Level
          </span>
          <span className="text-xs text-gray-600 dark:text-gray-400">
            {userRPPoints.toLocaleString()} / {maxPoints.toLocaleString()} RP
          </span>
        </div>
        <div className="flex h-3 gap-0.5 overflow-hidden rounded-full bg-card">
          <div
            className="bg-gradient-to-r from-teal-500 to-blue-500 dark:from-teal-400 dark:to-blue-400 transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
          <div className="flex-1 bg-transparent" />
        </div>
      </div>
    </Card>
  )
}
