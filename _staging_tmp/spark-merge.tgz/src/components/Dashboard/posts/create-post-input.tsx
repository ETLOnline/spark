import { NewPost, PostType, ImageFile } from "./types/posts-types"
import TagsInput from "../../TagsInput/TagsInput"
import "./create-post-input.css"
import { FileUpload } from "../../ui/file-upload"
import { useState } from "react"
import Tiptap from "../../common/Tiptap/TiptapRichEditor"

type PollOptionsSetter = (
  tags: string[] | ((tags: string[]) => string[])
) => void

type Props = {
  type: PostType
  setNewPost: (newPost: NewPost) => void
  newPost: NewPost
  pollOptions?: string[]
  setPollOptions?: (tags: string[] | ((tags: string[]) => string[])) => void
}

const CreatePostInput: React.FC<Props> = ({
  type,
  setNewPost,
  newPost,
  pollOptions,
  setPollOptions
}) => {
  const [selectedImages, setSelectedImages] = useState<ImageFile[]>([])

  const handleFiles = async (files: File[]) => {
    if (!files || files.length === 0) {
      setSelectedImages([])
      setNewPost({
        ...newPost,
        type: PostType.text,
        fileName: undefined,
        fileSize: undefined,
        fileType: undefined,
        fileBase64: undefined,
        images: undefined
      })
      return
    }

    if (type === PostType.image || type === PostType.poll) {
      // Reuse existing processed images when possible (for reorder/remove), otherwise read new ones
      const imagePromises = files
        .filter((file) => file.type.startsWith("image/"))
        .map((file) => {
          const existing = selectedImages.find(
            (si) =>
              si.name === file.name &&
              si.size === file.size &&
              si.type === file.type
          )
          if (existing) return Promise.resolve(existing)

          return new Promise<ImageFile>((resolve) => {
            const reader = new FileReader()
            reader.onloadend = () => {
              resolve({
                id: Math.random().toString(36).substr(2, 9),
                file,
                base64: reader.result as string,
                name: file.name,
                size: file.size,
                type: file.type
              })
            }
            reader.readAsDataURL(file)
          })
        })

      const processedImages = await Promise.all(imagePromises)
      setSelectedImages(processedImages)
      setNewPost({
        ...newPost,
        type: type === PostType.poll ? PostType.poll : PostType.image,
        images: processedImages
      })
      return
    }

    const file = files[0]
    const reader = new FileReader()
    reader.onloadend = () => {
      const base64String = reader.result as string
      setNewPost({
        ...newPost,
        type: file.type.startsWith("image/") ? PostType.image : PostType.file,
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type,
        fileBase64: base64String
      })
    }
    reader.readAsDataURL(file)
  }

  const handleRemoveFile = () => {
    setSelectedImages([])
    setNewPost({
      ...newPost,
      type: PostType.text,
      fileName: undefined,
      fileSize: undefined,
      fileType: undefined,
      fileBase64: undefined,
      images: undefined
    })
  }

  return type === PostType.text ? (
    <Tiptap
      placeholder="What's on your mind?"
      value={newPost.content as string}
      onChange={(content) =>
        setNewPost({
          ...newPost,
          content,
          type: PostType.text
        })
      }
    />
  ) : type === PostType.image ? (
    <div className="flex flex-col space-y-4">
      <div className="flex flex-col w-full pt-4">
        <FileUpload
          onChange={(files: File[]) => handleFiles(files)}
          onRemove={handleRemoveFile}
          accept="image/*"
          multiple={true}
          fileType="image"
        />
      </div>
      <Tiptap
        placeholder="Add a caption..."
        value={newPost.content as string}
        onChange={(content) =>
          setNewPost({
            ...newPost,
            content
          })
        }
        minHeight="60px"
      />
    </div>
  ) : type === PostType.poll ? (
    <div className="flex flex-col space-y-4">
      <div className="flex flex-col w-full pt-4">
        <FileUpload
          onChange={(files: File[]) => handleFiles(files)}
          onRemove={handleRemoveFile}
          accept="image/*"
          multiple={true}
          fileType="image"
        />
      </div>
      <Tiptap
        placeholder="Enter your poll question"
        value={newPost.content as string}
        onChange={(content) =>
          setNewPost({
            ...newPost,
            content,
            type: PostType.poll
          })
        }
      />
      <TagsInput
        tags={pollOptions as string[]}
        updateTags={setPollOptions as PollOptionsSetter}
        placeholder="Type an option and press Enter to add"
        type={type}
      />
    </div>
  ) : (
    <div className="flex flex-col space-y-4">
      <FileUpload
        onChange={(files: File[]) => handleFiles(files)}
        onRemove={handleRemoveFile}
        fileType="file"
      />
      <Tiptap
        placeholder="Add a description..."
        value={newPost.content as string}
        onChange={(content) =>
          setNewPost({
            ...newPost,
            content
          })
        }
        minHeight="60px"
      />
    </div>
  )
}

export default CreatePostInput
