import React from "react"
import "./footer.css"
import Link from "next/link"
import Image from "next/image"
import { ContactUsDialog } from "./ContactUsDialog"

function Footer() {
  return (
    <footer className="py-16 px-6 bg-gray-900 dark:bg-slate-950 text-white">
      <div className="container mx-auto">
        <div className="grid md:grid-cols-4 gap-12">
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="relative">
                <Image
                  src="/logo/spark-logo-animated-themed.gif"
                  width={40}
                  height={30}
                  alt="Spark logo"
                />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-primary via-primary-hover to-foreground bg-clip-text ">
                SPARK
              </span>
            </div>
            <p className="text-gray-400 leading-relaxed">
              Empowering Pakistan's tech future through collaboration,
              mentorship, and innovation. Building bridges between academia and
              industry.
            </p>
          </div>

          <div>
            <h3 className="font-bold mb-6 text-lg">Connect</h3>
            <ul className="space-y-3 text-gray-400">
              <li>
                <ContactUsDialog />
              </li>
              <li>
                <Link
                  href="/privacy"
                  className="hover:text-white transition-colors"
                >
                  Privacy
                </Link>
              </li>
              <li>
                <Link
                  href="/terms"
                  className="hover:text-white transition-colors"
                >
                  Terms
                </Link>
              </li>
              <li>
                <Link
                  href="/code-of-conduct"
                  className="hover:text-white transition-colors"
                >
                  Code of Conduct
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-gray-400">
          <p>
            &copy; 2024 SPARK Platform. All rights reserved. Built with ❤️ for
            Pakistan's tech community by{" "}
            <Link href="https://www.etlonline.org/" className="font-bold">
              ETLOnline.org
            </Link>{" "}
            .
          </p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
